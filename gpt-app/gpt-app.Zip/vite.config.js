import { svelte } from '@sveltejs/vite-plugin-svelte';
 
const config = {
  plugins: [svelte()]
};

export default config;
