import * as universal from "../../../../src/routes/+layout.ts";
export { universal };
export { default as component } from "../../../../node_modules/.pnpm/@sveltejs+kit@2.20.5_@svelt_a93539e779dbf2e3062825c1be1b7199/node_modules/@sveltejs/kit/src/runtime/components/svelte-5/layout.svelte";