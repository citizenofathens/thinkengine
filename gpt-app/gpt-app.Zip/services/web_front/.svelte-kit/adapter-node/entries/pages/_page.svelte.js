import { e as escape_html } from "../../chunks/escaping.js";
import "clsx";
import { c as pop, p as push } from "../../chunks/index2.js";
function _page($$payload, $$props) {
  push();
  let text = "";
  let message = "";
  $$payload.out += `<h1>메모 입력</h1> <textarea rows="5" cols="40">`;
  const $$body = escape_html(text);
  if ($$body) {
    $$payload.out += `${$$body}`;
  }
  $$payload.out += `</textarea> <br> <button>메모 생성</button> <p>${escape_html(message)}</p>`;
  pop();
}
export {
  _page as default
};
