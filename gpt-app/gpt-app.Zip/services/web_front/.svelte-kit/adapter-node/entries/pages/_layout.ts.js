import "../../chunks/index.js";
const prerender = true;
export {
  prerender
};
