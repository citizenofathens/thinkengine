

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.DLfe9yKT.js","_app/immutable/chunks/xOnqCGk-.js","_app/immutable/chunks/D48tj8qJ.js","_app/immutable/chunks/DECXn6Wz.js","_app/immutable/chunks/CqVWAEMT.js","_app/immutable/chunks/CXek_Yf8.js","_app/immutable/chunks/BISVnQfe.js"];
export const stylesheets = [];
export const fonts = [];
