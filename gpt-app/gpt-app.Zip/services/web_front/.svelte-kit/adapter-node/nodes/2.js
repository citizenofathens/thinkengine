

export const index = 2;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/2.B1O33eu_.js","_app/immutable/chunks/xOnqCGk-.js","_app/immutable/chunks/D48tj8qJ.js","_app/immutable/chunks/DECXn6Wz.js","_app/immutable/chunks/CqVWAEMT.js"];
export const stylesheets = [];
export const fonts = [];
