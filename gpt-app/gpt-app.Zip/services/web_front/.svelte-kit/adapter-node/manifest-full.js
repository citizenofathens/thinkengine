export const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "_app",
	assets: new Set(["favicon.png"]),
	mimeTypes: {".png":"image/png"},
	_: {
		client: {start:"_app/immutable/entry/start.CpoUqLx5.js",app:"_app/immutable/entry/app.oGW7n01u.js",imports:["_app/immutable/entry/start.CpoUqLx5.js","_app/immutable/chunks/CXek_Yf8.js","_app/immutable/chunks/D48tj8qJ.js","_app/immutable/chunks/BISVnQfe.js","_app/immutable/entry/app.oGW7n01u.js","_app/immutable/chunks/D48tj8qJ.js","_app/immutable/chunks/CqVWAEMT.js","_app/immutable/chunks/xOnqCGk-.js","_app/immutable/chunks/BISVnQfe.js"],stylesheets:[],fonts:[],uses_env_dynamic_public:false},
		nodes: [
			__memo(() => import('./nodes/0.js')),
			__memo(() => import('./nodes/1.js')),
			__memo(() => import('./nodes/2.js'))
		],
		routes: [
			{
				id: "/",
				pattern: /^\/$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 2 },
				endpoint: null
			}
		],
		prerendered_routes: new Set([]),
		matchers: async () => {
			
			return {  };
		},
		server_assets: {}
	}
}
})();
