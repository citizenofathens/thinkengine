<script context="module" lang="ts">
  export const prerender = true;
</script>

<main>
  <slot />
</main>
